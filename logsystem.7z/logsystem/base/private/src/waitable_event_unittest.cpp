/*

*/

#include "test.h"

#ifdef DO_UNITTEST

#include "waitable_event.h"
USING_NAMESPACE_BASE;


TEST_BEGIN(base, waitable_event) {

} TEST_END


#endif // DO_UNITTEST
