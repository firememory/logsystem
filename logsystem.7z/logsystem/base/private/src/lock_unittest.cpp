/*

*/

#include "test.h"

#ifdef DO_UNITTEST

#include "lock.h"
USING_NAMESPACE_BASE;


TEST_BEGIN(base, lock) {

} TEST_END


#endif // DO_UNITTEST
