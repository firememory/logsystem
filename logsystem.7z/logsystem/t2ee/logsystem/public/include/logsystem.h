/*

*/

#ifndef LOGSYSTEM_H_
#define LOGSYSTEM_H_

#include <config.h>
#include "error.h"


#if HAS_NAMESPACE
# define NAMESPACE_LOGSYSTEM_NAME       logsystem
# define BEGIN_NAMESPACE_LOGSYSTEM      BEGIN_NAMESPACE namespace NAMESPACE_LOGSYSTEM_NAME {
# define END_NAMESPACE_LOGSYSTEM        } END_NAMESPACE
# define USING_NAMESPACE_LOGSYSTEM      using namespace NAMESPACE_NAME::NAMESPACE_LOGSYSTEM_NAME
# define USING_LOGSYSTEM(x)             using NAMESPACE_LOGSYSTEM_NAME::x
#else
# define BEGIN_NAMESPACE_LOGSYSTEM
# define END_NAMESPACE_LOGSYSTEM
# define USING_NAMESPACE_LOGSYSTEM
# define USING_LOGSYSTEM(x)
#endif

#endif // LOGSYSTEM_H_
