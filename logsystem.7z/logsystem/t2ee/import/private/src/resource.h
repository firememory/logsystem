//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by import.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_IMPORT_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_LIST_FILE                   1000
#define IDC_BUTTON_LOG                  1001
#define IDC_EDIT_LOG                    1002
#define IDC_EDIT_DICT                   1003
#define IDC_EDIT_DATA                   1004
#define IDC_BUTTON_DICT                 1005
#define IDC_BUTTON_DATA                 1006
#define IDC_EDIT_TN                     1007
#define IDC_EDIT_DB                     1008
#define IDC_BUTTON_FILTER               1009
#define IDC_BUTTON_DB                   1010
#define IDC_BUTTON_TN                   1011
#define IDC_EDIT_FILTER                 1012
#define IDC_BUTTON_LOAD                 1013
#define IDC_EDIT_TNB                    1014
#define IDC_EDIT_TNB2                   1015
#define IDC_EDIT_SEP                    1015
#define IDC_BUTTON_REFRESH              1016
#define IDC_BUTTON_TNB                  1017
#define IDC_EDIT_LOGFALG                1018
#define IDC_EDIT_LOGFLAG                1018
#define IDC_BUTTON_LOGFLAG              1019
#define IDC_BUTTON_STOP                 1020
#define IDC_STATIC_PATH                 1021
#define IDC_BUTTON_SEP                  1022
#define IDC_BUTTON_TNB2                 1023
#define IDC_BUTTON_CT                   1023
#define IDC_EDIT_DBENG                  1024
#define IDC_BUTTON_DBENG                1025
#define IDC_CHECK1                      1026
#define IDC_CHECK_DBLOC                 1026
#define IDC_CHECK_DBLOC2                1027
#define IDC_CHECK_DELTEMPFILE           1027
#define IDC_EDIT_TIME_START             1028
#define IDC_EDIT_TIMERUN                1028
#define IDC_BUTTON_FILTER2              1029
#define IDC_STATIC_PATH2                1030
#define IDC_EDIT_FILTER2                1031
#define IDC_EDIT_FILTER_TIME            1031
#define IDC_EDIT_TIMERUN2               1032
#define IDC_EDIT_NETRATE                1032
#define IDC_STATIC_PATH3                1033
#define IDC_BUTTON_REFRESH2             1034
#define IDC_BUTTON_SAVECFG              1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
